Python BMP280
===================

Python library for accessing temperature and pressure measurments of BMP280 chip

Tested with Adafruit BMP280 temperature pressure sensors: https://www.adafruit.com/products/2651

Code used as a base:
https://github.com/gradymorgan/node-BMP280
https://github.com/adafruit/Adafruit_Python_BMP

To install run the setup.py file.

